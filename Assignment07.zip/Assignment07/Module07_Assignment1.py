#-------------------------------------------------#
# Title: Working with Exception Handling and Pickling
# Dev:   Hiroyuki Takechi
# Desc: 1) Create a simple example of how you would use Python Exception Handling. Make sure to comment your code
# Desc: 2) Create a simple example of how you would use Python Pickling. Make sure to comment your code
# Date:  May 21, 2017
#-------------------------------------------------#

# 1) Create a simple example of how you would use Python Exception Handling. Make sure to comment your code

#reference: http://coreblog.org/ats/stuff/minpy_support/samplecodes04/samplecodes/Chapter10/10-01.html
#reference: https://www.amazon.co.jp/dp/479738946X/trivialtechno-22/?ref=nosim

print("1) Create a simple example of how you would use Python Exception Handling. Make sure to comment your code", "\n")
print("Reference for the code:", "\n", "http://coreblog.org/ats/stuff/minpy_support/samplecodes04/samplecodes/Chapter10/10-01.html",
      "\n", "https://www.amazon.co.jp/dp/479738946X/trivialtechno-22/?ref=nosim", "\n")

def FileError(objF):
    for file in objF.split():
        try:
            objFile = open(file) #Assign file to objFile
        except FileNotFoundError as e: #Assign FileNotFoundError to e
            print("{} doesn't exist.".format(file),"FYI. Error class is {}: ".format(str(e.__class__)), "\n" ) #print error message if file doesn't exist.
        else:
            try:
                print("{} exists. The data in the file is:".format(file).strip(),"\n", objFile.read().strip(),"\n") #print message if file exists.
            finally:
                objFile.close() #close file

FileError('Products.txt')
FileError('test_no.txt')

# 2) Create a simple example of how you would use Python Pickling. Make sure to comment your code

#reference: http://coreblog.org/ats/stuff/minpy_support/samplecodes04/samplecodes/Chapter11/11-11.html
#reference: https://www.amazon.co.jp/dp/479738946X/trivialtechno-22/?ref=nosim

print("2) Create a simple example of how you would use Python Pickling. Make sure to comment your code:", "\n")
print("Reference for the code:", "\n", "http://coreblog.org/ats/stuff/minpy_support/samplecodes04/samplecodes/Chapter11/11-11.html",
      "\n", "https://www.amazon.co.jp/dp/479738946X/trivialtechno-22/?ref=nosim", "\n")

import pickle
data = ("This is the test for pickle.") #Create the object to convert into the pickle (binary) format
objFile_dat = open("C:\\_PythonClass\\Module07Project\\Example1.dat", "ab")
pickle_file= pickle.dump(data, objFile_dat) #Write out the object to file in pickle (binary) format
objFile_dat.close()

objFile_dat1 = open("C:\\_PythonClass\\Module07Project\\Example1.dat", "rb")
unpickle_file = pickle.load(objFile_dat1) #Coverting pickle format to readable format. Note that load() only load one row of data.
objFile_dat1.close()
print("'{}' is in the pickle test file.".format(unpickle_file))







