#--Make the Class--
class Product(object):
    """ Storing data """
    #-----------------------------------#
    #Desc: Storing Data
    #Dev: Hiroyuki Takechi
    #Date: 5/27/2017
    #ChangeLog: (when,who,what)
    #-----------------------------------#

    #--Field--
    Id = 0
    Name = ""
    Price = 0.00

    #--Constructor--
    def __init__(self,Id, Name, Price):
        self.__Id = Id
        self.__Name = Name
        self.__Price = Price

    #--Method--
    def ToString(self):
        return str(self.__Id)+","+str(self.__Name)+","+str(self.__Price)

    #Note: Sorry I tried to use Product class but code kept failing so I couldn't figure out...
    #...I'm just using ProductProcessor class only.
    #Products class
    # ''' ListOfProducts[], ShowAllItems()'''
    # strData = "1,'a',4.3"
    # lstData = strData.split(',')
    # objP = product(lstData[0],lstData[1],lstData[2])


class ProductProcessor(object):
    """ Processing data """
    #-----------------------------------#
    #Desc: Processing Data
    #Dev: Hiroyuki Takechi
    #Date: 5/27/2017
    #ChangeLog: (when,who,what)
    #-----------------------------------#

    #--Field--
    #objFile = None
    #strUserInput = None

    #--Constructor--
    def __init__(self, objFile = ""):
        #Attributes
        self.__objFile = objFile

    #--Properties--
    #objFile
    @property #(getter or accessor)
    def objFile(self):
        return self.__objFile
    @objFile.setter #(setter or mutator)
    def objFile(self, Value):
        self.__objFile = Value

    #strUserInput
    @property #(getter or accessor)
    def strUserInput(self):
        return self.__strUserInput
    @strUserInput.setter #(setter or mutator)
    def strUserInput(self, Value):
        self.__strUserInput = Value

    #--Methods--
    @staticmethod
    def WriteProductUserInput(objFile):
        try:
            print("Type in a Product Id, Name, and Price you want to add to the file")
            print("(Enter 'Exit' to quit!)")
            while(True):
                __strUserInput = input("Enter the Id, Name, and Price (ex. 1,ProductA,9.99): ")
                #lstData = __strUserInput.split(",")
                #objP = Product(lstData[0],lstData[1],lstData[2])
                if (__strUserInput.lower() == 'exit'):
                    break
                else:
                    objFile.write(__strUserInput + "\n")
        except Exception as e:
            print("Error: " + str(e))

    @staticmethod
    def ReadAllFileData(objFile, Message="Contents of File"):
        try:
            print(Message)
            objFile.seek(0)
            print(objFile.read())
        except Exception as e:
            print("Error: " + str(e))


    #--End of class--

#--Use the class--
#I/O
try:
  objFile = open("Product.txt", "r+")
  ProductProcessor.ReadAllFileData(objFile, "Here is the current data:")
  ProductProcessor.WriteProductUserInput(objFile)
  ProductProcessor.ReadAllFileData(objFile, "Here is this data was saved:")
except FileNotFoundError as e:
     print("Error: " + str(e) + "\n Please check the file name")
except Exception as e:
    print("Error: " + str(e))
finally:
  if(objFile != None):objFile.close()


