#-------------------------------------------------#
# Title: Working with Functions and Class
# Dev:   Hiroyuki Takechi
# Date:  May 14, 2017
#-------------------------------------------------#

# -- data code from Module 05 Assignment

objFile = open("C:\_PythonClass\Module06Project\Todo.txt", 'a')
tplRow1 = ("Clean House", "low")
tplRow2 = ("Pay Bills", "high")
tplTable = (tplRow1, tplRow2)
for row in tplTable:
    objFile.write(str(row[0]) + "," + str(row[1]) + "\n")
objFile.close()

objFile = open("C:\_PythonClass\Module06Project\Todo.txt", 'r')
lstTable = []
dictRow = {}
for line in objFile:
    strData = line
    lstRow = (strData.split(",")[0]).strip(), (strData.split(",")[1]).strip()
    dictRow = {'Task': lstRow[0], 'Priority': lstRow[1]}
    lstTable.append(dictRow)
#print("The following data is currently stored in a file: \n\r", lstTable)
objFile.close()

# -- def code for Module 06 Assignment
# Defining the functions for the menu
class TestClass(object):

    @staticmethod #@staticmethod doesn't create instance
    def showMenu():
        print("""
                Menu of Options
                1) Show current data
                2) Add a new item.
                3) Remove an existing item.
                4) Save Data to File
                5) Exit Program
                """)

    def showData(self): #(self) creates instance. self is just a convention
        return lstTable

    def AddItem(self, strTask, strPriority, exit):
        while (True):
            #strTask = input("Task: ")
            #strPriority = input("Priority (high/low): ")
            dicNewRow1 = {"Task": strTask, "Priority": strPriority}
            lstTable.append(dicNewRow1)
            if (input("Type 'exit' to complete?").lower() == "exit"): break
        return lstTable

    def RemoveItem(self, row, exit):
        while(True):
            #row = int(input("Enter the number of row to delete (starting with 0): "))
            lstTable.remove(lstTable[row])
            if (input("Type 'exit' to complete?").lower() == "exit"): break
        return lstTable

    def SaveData(self, exit):
        while(True):
            objF = open("C:\_PythonClass\Module06Project\Todo.txt", 'a')
            objF.write(str(lstTable))
            objF.close()
            if (input("Type 'exit' to complete?").lower() == "exit"): break
        return lstTable
        #print("The following data was saved to a file: \n\r", lstTable)

def main():

    # this piece of code instantiates the class so we can gain access to its functions.

    tc = TestClass()

    while(True):

        #Show Menu
        TestClass.showMenu()

        #choice input
        strChoice = str(input("Which option would you like to perform? [1 to 5] - "))
        print()

        #Show Table
        if (strChoice == '1'):
            s1 = tc.showData()
            print("The following data is currently stored in a table: \n\r", s1)

        #Add Item
        elif(strChoice == '2'):
            strTask = input("New Task: ")
            strPriority = input("New Priority (high/low): ")
            s2 = tc.AddItem(strTask, strPriority, exit)
            print("The following data is currently stored in a table: \n\r", s2)

        #Remove Item
        elif(strChoice == '3'):
            row = int(input("Enter the number of row to delete (starting with 0): "))
            s3 = tc.RemoveItem(row, exit)
            print("The following data is currently stored in a table: \n\r", s3)

        #Save Data
        elif(strChoice == '4'):
            s4 = tc.SaveData(lstTable)
            print("The following data was saved to a file: \n\r", s4)

        #Exit
        elif (strChoice == '5'):
            print("Good bye!")
            break

# -- presentation (I/O) code
# Call the method (functions)

if __name__ == "__main__":
    main()












